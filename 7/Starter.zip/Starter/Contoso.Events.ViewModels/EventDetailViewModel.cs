﻿using Contoso.Events.Models;

namespace Contoso.Events.ViewModels
{
    public class EventDetailViewModel
    {
        public Event Event { get; set; }
    }
}
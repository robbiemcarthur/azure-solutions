﻿namespace Contoso.Events.Models
{
    public enum RegistrationType
    {
        General = 0,
        Internal,
        Sales,
        Technical
    }
}